<?php
session_start();

// Cargar el autoload de Composer
require 'C:\xampp\htdocs\BARBERIA\vendor\autoload.php'; // Asegúrate de que la ruta sea correcta

// Configurar la clave secreta de Stripe
\Stripe\Stripe::setApiKey('sk_test_51Pah91AfMqazcVXecfqLCzVvw8zcsvtx4sAowkjzn9MMdm9xQUySYcuArv61SbNyTmS3fdhYbDorVmQ3IrrlhFYY00W8uruOF5');

// Obtener los parámetros de la URL
$session_id = $_GET['session_id'] ?? null;
$id_barbero = $_GET['id_barbero'] ?? null;
$fecha_reserva = $_GET['fecha_reserva'] ?? null;
$hora_reserva = $_GET['hora_reserva'] ?? null;
$nombre_cliente = $_GET['nombre_cliente'] ?? null;
$telefono_cliente = $_GET['telefono_cliente'] ?? null;

if ($session_id && $id_barbero && $fecha_reserva && $hora_reserva && $nombre_cliente && $telefono_cliente) {
    // Verificar el pago con Stripe
    try {
        $session = \Stripe\Checkout\Session::retrieve($session_id);

        if ($session->payment_status === 'paid') {
            // Guardar los datos en la base de datos
            require 'C:\xampp\htdocs\BARBERIA\conexion.php'; // Asegúrate de que la ruta sea correcta

            $query = "INSERT INTO reservas (id_servicio, id_barbero, fecha_reserva, hora_reserva, nombre_cliente, telefono_cliente, id_pago)
                      VALUES ('$_GET[id_servicio]', '$id_barbero', '$fecha_reserva', '$hora_reserva', '$nombre_cliente', '$telefono_cliente', '$session_id')";

            if (mysqli_query($conexion, $query)) {
                echo "Reserva completada exitosamente.";
            } else {
                echo "Error al guardar la reserva: " . mysqli_error($conexion);
            }
        } else {
            echo "El pago no fue completado.";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No se han recibido todos los datos necesarios.";
}
?>
