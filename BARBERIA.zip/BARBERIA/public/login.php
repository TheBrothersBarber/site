<?php
session_start();
require 'C:\xampp\htdocs\BARBERIA\conexion.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_barbero = $_POST['nombre_barbero'];
    $password_ingresada = $_POST['password'];

    $query = "SELECT id_barbero, nombre_barbero, password FROM barberos WHERE nombre_barbero = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param('s', $nombre_barbero);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $barbero = $result->fetch_assoc();
        $password = $barbero['password'];

        if ($password_ingresada === $password) {
            $_SESSION['loggedin'] = true;
            $_SESSION['id_barbero'] = $barbero['id_barbero'];
            $_SESSION['nombre_barbero'] = $barbero['nombre_barbero'];
            
            header("Location: admin_panel.php");
            exit;
        } else {
            $error = "Contraseña incorrecta.";
        }
    } else {
        $error = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Iniciar Sesión</h2>
    <?php if (!empty($error)) echo '<p class="error">' . htmlspecialchars($error) . '</p>'; ?>
    <form method="post" action="">
        <label for="nombre_barbero">Nombre de Usuario:</label>
        <input type="text" id="nombre_barbero" name="nombre_barbero" required>
        <br><br>
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>
        <br><br>
        <button type="submit">Iniciar Sesión</button>
    </form>
</body>
</html>