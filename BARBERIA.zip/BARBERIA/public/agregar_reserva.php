<?php
session_start();
require 'C:\xampp\htdocs\BARBERIA\conexion.php';

if (!isset($_SESSION['id_barbero'])) {
    header('Location: login.php');
    exit();
}

$tablas = ['RESEVAS', 'Servicios', 'barberos']; // Añade aquí todas las tablas que quieras incluir

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['tabla_seleccionada'])) {
        $tabla_seleccionada = $_POST['tabla_seleccionada'];
        $_SESSION['tabla_seleccionada'] = $tabla_seleccionada;
    } elseif (isset($_SESSION['tabla_seleccionada'])) {
        $tabla_seleccionada = $_SESSION['tabla_seleccionada'];
        
        // Procesar el formulario según la tabla seleccionada
        switch ($tabla_seleccionada) {
            case 'RESEVAS':
                $id_servicio = $_POST['id_servicio'];
                $nom_barbero = $_POST['nom_barbero'];
                $fecha_reserva = $_POST['fecha_reserva'];
                $hora_reserva = $_POST['hora_reserva'];
                $nombre_cliente = $_POST['nombre_cliente'];
                $telefono_cliente = $_POST['telefono_cliente'];
                $id_barbero = $_SESSION['id_barbero'];

                $query = "INSERT INTO RESEVAS (id_servicio, nom_barbero, fecha_reserva, hora_reserva, nombre_cliente, telefono_cliente, id_barbero) VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conexion->prepare($query);
                $stmt->bind_param('isssssi', $id_servicio, $nom_barbero, $fecha_reserva, $hora_reserva, $nombre_cliente, $telefono_cliente, $id_barbero);
                $stmt->execute();
                break;
            
            case 'Servicios':
                $nombre_servicio = $_POST['nombre_servicio'];
                $precio = $_POST['precio'];

                $query = "INSERT INTO Servicios (nombre_servicio, precio) VALUES (?, ?)";
                $stmt = $conexion->prepare($query);
                $stmt->bind_param('sd', $nombre_servicio, $precio);
                $stmt->execute();
                break;
            
            case 'barberos':
                $nombre_barbero = $_POST['nombre_barbero'];
                $password = $_POST['password'];

                $query = "INSERT INTO barberos (nombre_barbero, password) VALUES (?, ?)";
                $stmt = $conexion->prepare($query);
                $stmt->bind_param('ss', $nombre_barbero, $password);
                $stmt->execute();
                break;
        }

        header('Location: dashboard.php');
        exit();
    }
}

// Obtén los datos necesarios para el formulario de reservas
$query = "SELECT * FROM Servicios";
$result = $conexion->query($query);
$servicios = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Registro</title>
    <link rel="stylesheet" href="sesion.css">
</head>
<body>
    <h2>Agregar Registro</h2>
    
    <?php if (!isset($_SESSION['tabla_seleccionada'])): ?>
        <form method="post" action="">
            <label for="tabla_seleccionada">Selecciona la tabla:</label>
            <select name="tabla_seleccionada" required>
                <?php foreach ($tablas as $tabla): ?>
                    <option value="<?php echo htmlspecialchars($tabla); ?>"><?php echo htmlspecialchars($tabla); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Seleccionar</button>
        </form>
    <?php else: ?>
        <h3>Agregando a la tabla: <?php echo htmlspecialchars($_SESSION['tabla_seleccionada']); ?></h3>
        <form method="post" action="">
            <?php switch ($_SESSION['tabla_seleccionada']): 
                case 'RESEVAS': ?>
                    <label for="id_servicio">Servicio:</label>
                    <select name="id_servicio" required>
                        <?php foreach ($servicios as $servicio): ?>
                            <option value="<?php echo htmlspecialchars($servicio['id_servicio']); ?>"><?php echo htmlspecialchars($servicio['nombre_servicio']); ?></option>
                        <?php endforeach; ?>
                    </select><br>
                    <label for="nom_barbero">Nombre del Barbero:</label>
                    <input type="text" name="nom_barbero" required><br>
                    <label for="fecha_reserva">Fecha de Reserva:</label>
                    <input type="date" name="fecha_reserva" required><br>
                    <label for="hora_reserva">Hora de Reserva:</label>
                    <input type="time" name="hora_reserva" required><br>
                    <label for="nombre_cliente">Nombre del Cliente:</label>
                    <input type="text" name="nombre_cliente" required><br>
                    <label for="telefono_cliente">Teléfono del Cliente:</label>
                    <input type="text" name="telefono_cliente" required><br>
                <?php break; ?>
                
                <?php case 'Servicios': ?>
                    <label for="nombre_servicio">Nombre del Servicio:</label>
                    <input type="text" name="nombre_servicio" required><br>
                    <label for="precio">Precio:</label>
                    <input type="number" step="0.01" name="precio" required><br>
                <?php break; ?>
                
                <?php case 'barberos': ?>
                    <label for="nombre_barbero">Nombre del Barbero:</label>
                    <input type="text" name="nombre_barbero" required><br>
                    <label for="password">Contraseña:</label>
                    <input type="password" name="password" required><br>
                <?php break; ?>
            <?php endswitch; ?>
            
            <button type="submit">Agregar Registro</button>
        </form>
        <br>
        <form method="post" action="">
            <button type="submit" name="cambiar_tabla">Cambiar Tabla</button>
        </form>
    <?php endif; ?>

    <?php
    if (isset($_POST['cambiar_tabla'])) {
        unset($_SESSION['tabla_seleccionada']);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
    ?>
</body>
</html>