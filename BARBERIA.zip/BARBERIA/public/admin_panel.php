<?php
session_start();
require 'C:\xampp\htdocs\BARBERIA\conexion.php';

if (!isset($_SESSION['id_barbero'])) {
    header('Location: login.php');
    exit();
}

$rol = $_SESSION['rol'];

// Consulta de datos
$query = "SELECT * FROM Servicios";
$result = $conexion->query($query);
$servicios = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="sesion.css">
</head>
<body>
    <h2>Dashboard</h2>
    <a href="logout.php">Cerrar Sesión</a>
    
    <h3>Servicios</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($servicios as $servicio): ?>
                <tr>
                    <td><?php echo htmlspecialchars($servicio['id_servicio']); ?></td>
                    <td><?php echo htmlspecialchars($servicio['nombre_servicio']); ?></td>
                    <td><?php echo htmlspecialchars($servicio['precio']); ?></td>
                    <td><?php echo htmlspecialchars($servicio['descripcion_servicio']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($rol === 'admin'): ?>
        <a href="agregar_reserva.php">Agregar </a>
        <a href="modificar_servicio.php">Modificar</a>
        <a href="eliminar_servicio.php">eliminar</a>
        <a href="ver_info.php">ver tabla</a>
        <!-- Enlaces para modificar y eliminar servicios -->
    <?php endif; ?>
</body>
</html>
