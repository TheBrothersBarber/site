<?php
session_start();
require 'C:\xampp\htdocs\BARBERIA\conexion.php';

if (!isset($_SESSION['id_barbero']) || $_SESSION['rol'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$tablas = ['Servicios', 'RESEVAS', 'barberos']; // Añade aquí todas las tablas que quieras incluir

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['tabla_seleccionada'])) {
        $_SESSION['tabla_seleccionada'] = $_POST['tabla_seleccionada'];
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    } elseif (isset($_POST['id_eliminar'])) {
        $_SESSION['id_eliminar'] = $_POST['id_eliminar'];
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    } elseif (isset($_POST['confirmar_eliminacion'])) {
        $tabla = $_SESSION['tabla_seleccionada'];
        $id = $_SESSION['id_eliminar'];
        $campo_id = 'id_' . strtolower(substr($tabla, 0, -1)); // Suponiendo que los campos ID siguen este patrón

        $query = "DELETE FROM $tabla WHERE $campo_id = ?";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param('i', $id);
        $stmt->execute();

        unset($_SESSION['tabla_seleccionada']);
        unset($_SESSION['id_eliminar']);
        header('Location: dashboard.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Registro</title>
    <link rel="stylesheet" href="sesion.css">
</head>
<body>
    <h2>Eliminar Registro</h2>

    <?php if (!isset($_SESSION['tabla_seleccionada'])): ?>
        <form method="post" action="">
            <label for="tabla_seleccionada">Selecciona la tabla:</label>
            <select name="tabla_seleccionada" required>
                <?php foreach ($tablas as $tabla): ?>
                    <option value="<?php echo htmlspecialchars($tabla); ?>"><?php echo htmlspecialchars($tabla); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Seleccionar</button>
        </form>
    <?php elseif (!isset($_SESSION['id_eliminar'])): ?>
        <form method="post" action="">
            <label for="id_eliminar">Ingresa el ID del registro a eliminar:</label>
            <input type="number" name="id_eliminar" required>
            <button type="submit">Seleccionar</button>
        </form>
    <?php else: ?>
        <p>¿Estás seguro de que quieres eliminar este registro de la tabla <?php echo htmlspecialchars($_SESSION['tabla_seleccionada']); ?> con ID <?php echo htmlspecialchars($_SESSION['id_eliminar']); ?>?</p>
        <form method="post" action="">
            <button type="submit" name="confirmar_eliminacion">Eliminar</button>
            <a href="<?php echo $_SERVER['PHP_SELF']; ?>">Cancelar</a>
        </form>
    <?php endif; ?>

</body>
</html>